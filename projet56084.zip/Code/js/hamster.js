const energyCurrentHTML = document.querySelector('#energy-current')
const energyFullHTML = document.querySelector('#energy-full')
const playground = document.querySelector('#hamster-play')
const balanceHTML = document.querySelector('#balance')
const dailyCodeBtn = document.querySelector('#daily-code-btn')
const circleOuter = playground.querySelector('#circle-outer')
const circleInner = playground.querySelector('#circle-inner')
const dailycodeBlock = document.querySelector('#dailycode-block')

const player = {
    energyCurrent: 1000,
    energyFull: 1000,
    tapStrength: 15,
    rechargeSpeed: 10,
    money: 0
}

const app = {
    rechargeTimer: null,
    codeModeIsOn: false
}

energyCurrentHTML.textContent = player.energyCurrent
energyFullHTML.textContent = player.energyFull
balanceHTML.textContent = player.money


window.oncontextmenu = function(event) {
    event.preventDefault();
    event.stopPropagation();
    return false;
};



function setPlaygroundEvents() {

    console.log(app.codeModeIsOn)

    

    
    playground.addEventListener('click', e => {

        if (player.energyCurrent < player.tapStrength) return
    
        removeEnergy(player.tapStrength)
        moneyUp(player.tapStrength)
    
        showFlyScores(player.tapStrength, {
            x: e.offsetX,
            y: e.offsetY
        }, app.codeModeIsOn)
    
        if (app.rechargeTimer === null) recharge()
    })

}
setPlaygroundEvents()


// playground.addEventListener(clickEvent, e => {
//     if (player.energyCurrent < player.tapStrength) return

//     removeEnergy(player.tapStrength)
//     moneyUp(player.tapStrength)

//     showFlyScores(player.tapStrength, {
//         x: e.offsetX,
//         y: e.offsetY
//     }, app.codeModeIsOn)

//     if (app.rechargeTimer === null) recharge()
// })




dailyCodeBtn.addEventListener('click', () => {
    app.codeModeIsOn ? codeModeOff() : codeModeOn()
})


function removeEnergy(energyValue) {
    player.energyCurrent -= energyValue

    if (player.energyCurrent <= 0) {
        player.energyCurrent = 0
    }

    energyCurrentHTML.textContent = player.energyCurrent
}


function showFlyScores(tapStrength, coordinates, codeModeIsOn) {
    let score = document.createElement('div')
    score.classList.add('hamster__playground-click')

    score.style.top = coordinates.y + 'px'
    score.style.left = coordinates.x + 20 + 'px'
    
    if (!codeModeIsOn) {
        score.textContent = `+${tapStrength}`
    } else {
        score.classList.add('hamster__playground-click--point')
    }
    
    playground.append(score)

    score.animate([
        { transform: 'translateY(0px)' },
        { transform: 'translateY(-200px)', opacity: 0 }
    ], {
        duration: 1000,
    })

    setTimeout(() => {
        score.remove()
    }, 700)

}


function recharge() {
    if (player.energyCurrent < player.energyFull) {

        app.rechargeTimer = setInterval(() => {
            player.energyCurrent += player.rechargeSpeed

            if (player.energyCurrent >= player.energyFull) {
                clearInterval(app.rechargeTimer)
                player.energyCurrent = player.energyFull
                app.rechargeTimer = null
            }
            energyCurrentHTML.textContent = player.energyCurrent

        }, 1000)
    }
}
recharge()


function moneyUp(moneyValue) {
    balanceHTML.textContent = player.money += moneyValue
}

function codeModeOn() {
    circleOuter.classList.add('hamster__playground-circle--codemode')
    circleInner.classList.add('hamster__playground-circle-inner--codemode')
    dailycodeBlock.classList.remove('hide')
    app.codeModeIsOn = true
}

function codeModeOff() {
    circleOuter.classList.remove('hamster__playground-circle--codemode')
    circleInner.classList.remove('hamster__playground-circle-inner--codemode')
    dailycodeBlock.classList.add('hide')
    app.codeModeIsOn = false
}